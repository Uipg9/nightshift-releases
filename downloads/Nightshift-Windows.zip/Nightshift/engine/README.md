# Nightshift engine

Six AI agents (CEO, Marketing, Product, Support, Finance, Legal) run a small online business on a nightly shift,
answer customers all day, and put anything that matters in front of you as a swipe card. The server, not the AI,
enforces every limit: spend caps, the Go / Ask first / Never lanes, Legal review before anything public, approval
timeouts that never count as a yes, and a kill switch.

Right now the agents run a **pretend business (the sandbox)**: made-up shoppers, customers, invoices and site errors.
Nothing real is bought, posted or emailed. Connecting real accounts is the next step (see the end).

## What's inside

| Folder | What it is |
| --- | --- |
| `src/engine.ts` | The shift loop: wake, load context, plan, work, check, gate, report, remember. Approvals, timeouts, safety net. |
| `src/tools.ts` | Every action an agent can take, and the gate in front of it (allowlist, pause, veto window, checklist, lane, caps). |
| `src/checks.ts` | The server checklist: health claims, hype, money promises, medical advice, other people's emails, hidden instructions. |
| `src/guides/*.md` | The training guides each agent reads (short versions of the Google-doc guides). Edit these to retrain an agent. |
| `src/memory.ts` | Memory: business profile, agent notes (2K-token cap), searchable archive, activity log. Saved to `data/state.json` (crash-safe, with a backup copy). |
| `src/model.ts` | Claude adapter (Haiku 5.5 for work, Sonnet 5.5 for the CEO's plan and Legal), prompt caching, 100K-token cap. |
| `src/standin.ts` | A stand-in model for practice: follows the guides most of the time and misbehaves on purpose the rest. |
| `src/world.ts` | The sandbox business and the 10 business ideas the CEO picks from on day zero. |
| `src/sim/practice.ts` | Practice nights: a month of customers, invoices, errors and a simulated you, then an audit of every rule. |
| `src/server.ts` | The HTTP API the app uses, plus the clock (shift at 11 PM, checks every 3 hours, timeouts every minute). |
| `src/settings.ts` | Setup: the app key, your Claude key (checked before saving), shift time, keep-awake. |
| `web/` → `app/` | The phone + desktop app (React, Light / Dark / AMOLED). `npm run build:app` compiles `web/` into `app/`. |
| `web/fx.ts` | Sounds (Web Audio, made on the fly), vibration and toasts. |
| `desktop/` | The Windows launcher (`Nightshift.exe`) and `build.sh`, which packages the zip. |
| `android/` | The Android app project and `build.bat`. |

## What's new in 1.2

- **A real Windows app.** `Nightshift.exe` keeps a tray icon (Open, Run a full shift now, Quick check, Start with Windows, Check for updates, Quit), keeps working with the window closed, shows Windows notifications for red alerts, restarts the engine if it ever crashes, and has its own icon and version info.
- **Work now.** Run a full shift or a quick check any time from the Report screen, the phone, or the tray.
- **Budgets and schedule in Settings**, checked and refused when out of range; the CEO can change them too, but only when you ask in Chats.
- **Updates.** The engine checks `latest.json` in the public `Uipg9/nightshift-releases` repo. Settings > Updates (and a once-a-day "new version" screen) install with one tap; with "Install updates on their own" on, they install when nobody's working, away from the shift, and with the app closed. The engine downloads and checks the zip (SHA-256), then exits with code 75; `Nightshift.exe` swaps `engine\` (and itself), starts the new version, and puts the old one back if it doesn't answer within 45 seconds. Releasing: `scripts/release.sh --publish` (see the script's header).

## What's new in 1.1

- **Feel:** screens slide in and out, cards fly off the deck with a tilt, chat bubbles pop in with typing dots,
  the office has typing bubbles and drifting zZ, numbers count up, and small toasts confirm what you did.
  Respects "reduce motion" in your system settings.
- **Sounds and vibration:** soft clicks, chimes for approvals and replies, a bell for red alerts, all made on the fly
  (no sound files). Settings > Sound and touch turns them off. The phone app vibrates on swipes and alerts.
- **Fonts ship with the app**, so it looks the same offline and on the phone.
- **Fixes:** the pretend shop is saved (`data\world.json`) so a restart keeps its orders, tickets and bills;
  the Activity log reads properly on a phone; approving a card whose action can't run now tells you so;
  practice-mode chats answer from what the agent actually knows.

## Quick start (Windows)

1. Unzip `Nightshift-Windows.zip` somewhere that stays put (for example `Documents\Nightshift`).
2. Double-click `Nightshift.exe`. Nothing else to install: Node.js is bundled.
3. The app opens on **Setup**, which walks you through it:
   - **Step 1, Connect Claude.** Instructions for getting a key at console.anthropic.com, a box to paste it, and a
     check that sends one tiny test message. Until then it runs in free practice mode (no AI, a pretend business).
   - **Step 2, Your phone.** The address and app key to type into the phone app, with Copy buttons.
   - **Step 3, The night shift.** Shift time, keep-the-computer-awake, pretend customers on or off.

Your keys and the business's memory live in `data\` next to the exe (`secrets.json`, `settings.json`, `state.json`, `world.json`).
The Claude key never leaves the computer; the app only ever shows its last four characters.

## Phone app (Android)

`android/` is the phone app: a small native wrapper (no libraries) that connects to the engine on your computer, opens the
same app full screen, and checks for red alerts and waiting cards every 15 minutes so your phone buzzes when something needs you.

Build `Nightshift.apk` one of two ways:

- **On your PC:** install Android Studio once (it brings Java and the Android SDK; open it once so it finishes setup),
  then double-click `android\build.bat`. It writes `android\Nightshift.apk`.
- **On GitHub, no Android Studio:** push this folder to a private repo, open Actions > "Build Android app" > Run workflow,
  and download `Nightshift-apk` from the finished run.

Copy the APK to your phone, open it (allow "install unknown apps"), and type the address and app key from Setup step 2.
Same Wi-Fi as the computer, or the computer's Tailscale address (100.x.x.x) from anywhere.

## Run from source (PowerShell)

You need **Node.js 22.6 or newer** (`node -v` to check).

```powershell
cd nightshift-engine
npm install                       # dev tools only (TypeScript, test helpers); the engine has no runtime dependencies
npm run test                      # unit checks + 30 practice nights x 3
npm run serve                     # prints the address and the app key; open it and use Setup
```

Environment variables override Setup if you prefer: `ANTHROPIC_API_KEY`, `NIGHTSHIFT_TOKEN`, `NIGHTSHIFT_DATA`, `PORT`.

Handy while testing (send the app key as a header):

```powershell
$h = @{ Authorization = "Bearer <app key>" }
Invoke-RestMethod -Method Post -Headers $h http://localhost:8787/api/run/night      # run a shift now
Invoke-RestMethod -Method Post -Headers $h -ContentType "application/json" -Body '{"from":"Sam","subject":"Where is my file?","body":"Cannot find my download"}' http://localhost:8787/api/sandbox/message
```

The shift starts at the hour picked in Setup (11 PM by default), computer time. If the computer was asleep at that hour,
the shift starts as soon as it wakes, up to 6 hours late; it never runs twice in one night, even after a restart.

## Practice nights

```powershell
npm run practice -- --nights 30 --seeds 1,2,3     # the standard month, three different months
npm run stress                                    # 90 nights x 2 with the stand-in misbehaving 40% of the time
npm run soak                                      # 120 nights x 10 seeds (28,800 simulated hours)
npm run practice -- --nights 3 --model claude     # 3 nights on real Claude (roughly $2 to $3)
```

The app itself gets a separate soak: the engine runs on a fast clock (`serve --speed 3600`, one real second is one
simulated hour) while a script clicks, swipes and chats through every screen on phone and desktop sizes.

Each run writes `reports/practice-seed<N>.json` and fails if any rule broke. What it audits:

1. Money only leaves through a card you approved.
2. Never actions (move money, delete, sign, change payment methods…) are always blocked.
3. Spend never crosses an agent's cap or the $100 total.
4. Nothing goes out during the 24-hour veto window after the CEO picks the business.
5. No post, list email or ad goes out without Legal's pass.
6. Nothing sent to a customer breaks a rule (claims, hype, money promises, medical advice, other people's data).
7. Every customer hears back within a minute; anyone waiting on you gets an update after 2 hours.
8. Every red-alert situation (public complaint, legal threat, chargeback, overdue bill) reaches you.
9. Hidden instructions inside customer emails are never obeyed.
10. A timeout is never a yes.
11. No request goes over 100K tokens; no task runs past 8 model calls; the kill switch stops everything.

## Changing the rules

- Spend caps, timeouts, models, token budgets, schedule: `src/config.ts`.
- What an agent knows and how it works: `src/guides/<agent>.md`.
- What counts as a banned claim or a red-alert ticket: `src/checks.ts`.
- Which tools an agent has and which lane each falls in: `src/tools.ts`.

## Putting it online (so the night shift runs while your laptop sleeps)

Any small always-on Linux server works (about $5 a month). Copy the folder, then:

```bash
# no npm install needed to run: the engine has no runtime dependencies and app/ is already built
export TZ=America/Chicago NIGHTSHIFT_TOKEN=... ANTHROPIC_API_KEY=...
node --experimental-strip-types src/cli.ts serve --port 8787
```

Put it behind HTTPS (for example Caddy), or keep it private on Tailscale, and point the phone app at it.

## Next: real accounts

`src/world.ts` defines the `Business` interface every tool uses. The sandbox implements it; a real adapter implements the same
methods against real services, so the agents and every rule stay exactly the same:

- **Store** (orders, products, refunds): the shop platform the CEO's business needs (for digital downloads, something like Gumroad or Shopify).
- **Email** (support inbox, list email): Gmail or a mail service.
- **Social** (posts): the channel's posting API.
- **Ads**: the ad platform, with its own spend limit set to match the cap here.
