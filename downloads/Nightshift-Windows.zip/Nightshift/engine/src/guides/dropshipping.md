# Dropshipping playbook

This business is a dropshipping store. We sell physical products on our own store. When an order comes in, the supplier is charged automatically and ships straight to the customer. We never hold stock. The money is in the gap between our price and the supplier's cost, minus payment fees, returns and ads. The work is in picking good products, being honest about shipping, and looking after customers when the supplier slips.

Dropshipping is legal in the US. Running it badly is what gets stores in trouble: late orders nobody is told about, misleading ads, fake reviews, unsafe or knockoff products, and sales tax ignored. The rules below keep us on the right side. Nothing here replaces a lawyer or the Wisconsin Department of Revenue; when Brian asks something this playbook doesn't cover, say so and point him to them.

## How it works, in plain words (for explaining to Brian)
- Customer buys on our store at our price. The store (for example Shopify with a supplier app) passes the order to the supplier, who charges us their price and ships it in plain packaging.
- Margin per order = our price - supplier cost - payment fee (about 3%) - a share of ads and refunds. A product needs at least a 1.6x markup to be worth it.
- What makes or breaks it: reliable suppliers (US warehouses ship in days; overseas can take weeks and now pays import duties), honest shipping times, a product people want that isn't regulated, and good customer service when things go wrong.

## Products: what we will and won't sell
- Good fits: simple home, desk, organizing, decor and accessory items; not branded, not regulated, not fragile, easy to describe honestly.
- Never: anything for children 12 and under (lab testing and certificates required), food, drinks, supplements, cosmetics and skin care, anything electrical or with a battery, weapons or self-defense items, medical or safety gear, anything that touches food, cheap metal jewelry, pet food or flea/tick products, and anything with another company's brand, logo or character, or "dupes", "replicas" and copies. The server screens new products (add_product) for these; don't try to word around it.
- Prefer suppliers with US warehouses: faster shipping, fewer delays, and no import duties on each parcel. Since August 2025 low-value imports no longer enter duty-free, so overseas suppliers cost more and take longer.
- Use the supplier's product photos only if the supplier allows it; write our own descriptions. Describe exactly what it is (size, material, what's in the box). No claims we can't back up.

## Shipping promises (FTC Mail, Internet, or Telephone Order Merchandise Rule)
- Only promise a ship time we have a reasonable basis to meet: the supplier's real window, not the best case. If we state no time, the law assumes 30 days. This store's window is in the profile; use it everywhere (product pages, FAQ, replies).
- Never say "ships today", "next-day", "2-day" or "arrives tomorrow" unless the supplier really does that. The server blocks those phrases in public text.
- Shipping delays: when the supplier pushes an order past the promised date, the customer must hear about it before that date passes. Send notify_shipping_delay with the new ship date and a plain line that they can cancel for a full refund instead. If they cancel, the refund must happen promptly (within a billing cycle for card payments): put the refund card in front of Brian right away and say in it that the law requires it. The server sends the notice itself if Support misses it.
- If the new date is more than 30 days past the original promise, or we don't know when it will ship, ask Brian: the customer has to agree to that delay or the order gets cancelled and refunded.

## Customer support for a store that ships
- "Where is my order?" is the most common ticket. read_orders, then answer with the status, the tracking number if shipped, and the date it should arrive (shipped orders take about 3 more days). Honest dates only.
- Damaged, wrong item, never arrived, or wants to return: these involve money, so it goes to Brian (holding reply, then a card). Ask for a photo of damage politely.
- Returns follow the store's published policy. Never promise more than the policy says.
- A chargeback (the customer disputed the charge with their bank) is red: alert Brian. Finance gathers the order, tracking and delivery proof for his reply to the payment processor.

## Marketing (FTC advertising rules)
- Everything public must be true and provable. No fake or made-up reviews, star ratings or "thousands of happy customers" (the FTC's fake-review rule carries civil penalties). Quote a real review only with the customer's permission.
- No fake urgency ("only 3 left", "ends tonight") unless it's literally true. No "was $40, now $24" unless we really sold it at $40 for a meaningful time. No "Made in USA" unless it truly is.
- Email the list only people who signed up; every email needs an unsubscribe line and the business's mailing address (CAN-SPAM). Text messages need written consent first; don't do SMS without Brian.
- Ads: start tiny, one product, one audience. Ad spend always goes through Brian's card.

## Finance
- Track per order: price, supplier cost, fees, refunds. Report margin, not just revenue.
- Sales tax: Brian lives in Wisconsin, so the store has a Wisconsin sales location. Wisconsin requires a seller's permit before making taxable retail sales there, and sales tax on Wisconsin orders. Other states only require registration after a seller passes that state's threshold (often $100,000 a year in sales into the state). Remind Brian of the permit before real sales start; never file or pay anything.
- Income: profit is taxable income for Brian. Payment processors send a 1099-K once sales pass $20,000 and 200 transactions in a year, but income is taxable either way. Suggest he keeps business money separate and sets some aside for taxes.

## Legal's checklist for this store (before real sales)
- Published refund and returns policy (Shopify requires one), shipping policy with the real window, privacy policy, and terms. Product drafts them; Legal checks them against this playbook; Brian approves.
- Every product passed the screen above; every description is accurate.
- Brian has his Wisconsin seller's permit and the store collects sales tax on Wisconsin orders.
- Optional but wise as it grows: a business bank account, an LLC, and product liability insurance (sellers can be liable for a product that hurts someone even if they never touched it).
