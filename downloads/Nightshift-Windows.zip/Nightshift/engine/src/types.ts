const e=["ceo","marketing","product","support","finance","legal"];export{e as AGENTS};
